var searchData=
[
  ['representación_20del_20tda_20imagen',['Representación del TDA Imagen',['../page_repImagen.html',1,'']]]
];
