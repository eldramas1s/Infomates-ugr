var searchData=
[
  ['get_5fcols',['get_cols',['../classImage.html#a8503fbbfd1710d8dc8f48a4d03791b25',1,'Image']]],
  ['get_5fpixel',['get_pixel',['../classImage.html#a029c2abbef622b0c971ca20ef1b751f4',1,'Image::get_pixel(int i, int j) const '],['../classImage.html#ac9f2921e648dfa46731c97faf5442543',1,'Image::get_pixel(int k) const ']]],
  ['get_5frows',['get_rows',['../classImage.html#a4e3dc9695196fcec8cf53b884ce487e4',1,'Image']]]
];
