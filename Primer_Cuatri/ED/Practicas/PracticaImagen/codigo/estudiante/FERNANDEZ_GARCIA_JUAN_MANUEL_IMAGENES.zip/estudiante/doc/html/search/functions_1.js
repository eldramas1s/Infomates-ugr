var searchData=
[
  ['crop',['Crop',['../classImage.html#ad11af6b413a33b9298d7ec2de46f026a',1,'Image']]]
];
