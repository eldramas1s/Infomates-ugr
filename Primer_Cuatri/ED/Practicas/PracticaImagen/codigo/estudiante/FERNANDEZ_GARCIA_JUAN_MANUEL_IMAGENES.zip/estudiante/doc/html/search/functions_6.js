var searchData=
[
  ['mean',['Mean',['../classImage.html#a2917970495ba9a018012ccff7e8b423b',1,'Image']]]
];
