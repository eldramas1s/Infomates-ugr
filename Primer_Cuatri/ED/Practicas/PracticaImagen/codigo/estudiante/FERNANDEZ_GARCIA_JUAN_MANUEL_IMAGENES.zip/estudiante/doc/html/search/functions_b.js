var searchData=
[
  ['zoom2x',['Zoom2X',['../classImage.html#a2b01a60815077bd04e68d30943663c3f',1,'Image']]]
];
