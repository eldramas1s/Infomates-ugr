var searchData=
[
  ['save',['Save',['../classImage.html#ac0987139dd4a4ba217dd865885d2a5cc',1,'Image']]],
  ['set_5fpixel',['set_pixel',['../classImage.html#a6e316f867fd3b67a75d78ca66bc12195',1,'Image::set_pixel(int i, int j, byte value)'],['../classImage.html#adf54cab55e991b8fac7d8043507588cb',1,'Image::set_pixel(int k, byte value)']]],
  ['shufflerows',['ShuffleRows',['../classImage.html#a27d5bab7af11a729048b82af06f2d0c0',1,'Image']]],
  ['size',['size',['../classImage.html#afc62d45cff0385a515a725e8c6b7e948',1,'Image']]],
  ['subsample',['Subsample',['../classImage.html#a71e747b356fd504dfca229bb67ceb8ba',1,'Image']]]
];
