#include "../Comportamientos_Jugador/auxiliar.hpp"
#include <iostream>
#include "motorlib/util.h"

Action ComportamientoAuxiliar::think(Sensores sensores)
{
	Action accion = IDLE;

	switch (sensores.nivel)
	{
	case 0:
		accion = ComportamientoAuxiliarNivel_0 (sensores);
		break;
	case 1:
		accion = ComportamientoAuxiliarNivel_1 (sensores);
		break;
	case 2:
		// accion = ComportamientoAuxiliarNivel_2 (sensores);
		break;
	case 3:
		// accion = ComportamientoAuxiliarNivel_3 (sensores);
		break;
	case 4:
		// accion = ComportamientoAuxiliarNivel_4 (sensores);
		break;
	}

	return accion;
}

int ComportamientoAuxiliar::interact(Action accion, int valor)
{
	return 0;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_0(Sensores sensores)
{
	SituarSensorEnMapa(mapaResultado,mapaCotas,sensores);

	Action action;

	frecuencias[sensores.posF][sensores.posC]++; //Actualizo la matriz de frecuencias

	if(sensores.superficie[0]=='D') zap=true;
	if(sensores.superficie[0]=='X')
		action=IDLE;
	
	else if(giro45izq!=0){
		action = TURN_SR;
		giro45izq--;
	}
	else if(giro180!=0){
		action=TURN_SR;
		giro180--;
	}
	else if(sensores.choque){
		action=TURN_SR;
		giro180=3;
	}
	else{
		int pos=Andar(sensores);
		if(pos == 2){
			action = WALK;
		}
		else if(pos == 0)
			action = TURN_SR;
		else {
			action = TURN_SR;
			if(pos == 1){
				giro45izq = 6;
			}
		}

	}
	return action;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_1(Sensores sensores)
{
	SituarSensorEnMapa(mapaResultado,mapaCotas,sensores);

	Action action;
	
	ActualizarFrecs(sensores.posF,sensores.posC,sensores.rumbo);


	if(sensores.superficie[0]=='D') zap=true;
	if(sensores.superficie[0]=='X')
		action=IDLE;
	
	else if(giro45izq!=0){
		action = TURN_SR;
		giro45izq--;
	}
	else if(giro180!=0){
		action=TURN_SR;
		giro180--;
	}
	else if(sensores.choque){
		action=TURN_SR;
		giro180=3;
	}
	else{
		int pos=Andar(sensores);
		if(pos == 2){
			action = WALK;
		}
		else if(pos == 0)
			action = TURN_SR;
		else {
			action = TURN_SR;
			if(pos == 1){
				giro45izq = 6;
			}
		}

	}
	return action;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_2(Sensores sensores)
{
	return IDLE;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_3(Sensores sensores)
{
	return IDLE;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_4(Sensores sensores)
{
	return IDLE;
}


/***************************************/
//Funciones importantes
/***************************************/

int ComportamientoAuxiliar::GetPos(int fila,int col, Orientacion rumbo){
	int pos=0;
	int k=1;
	switch (rumbo)
	{
		case sur:
			k=-1;
		case norte:
			if(fila==0) pos=0;
			else if(fila==-k){
				if(col==-k) pos=1;
				else if(col==0) pos=2;
				else if(col==k) pos=3;
			}
			else if(fila==-2*k){
				if(col==-2*k) pos=4;
				else if(col==-k) pos=5;
				else if(col==0) pos=6;
				else if(col==k) pos=7;
				else if(col==2*k) pos=8;
			}
			else if(fila==-3*k){
				if(col==-3*k) pos=9;
				else if(col==-2*k) pos=10;
				else if(col==-k) pos=11;
				else if(col==0) pos=12;
				else if(col==k) pos=13;
				else if(col==2*k) pos=14;
				else if(col==3*k) pos=15;
			}
		break;
		case oeste:
			k=-1;
		case este:
			if(col==0) pos=0;
			else if(col==k){
				if(fila==-k) pos=1;
				else if(fila==0) pos=2;
				else if(fila==k) pos=3;
			}
			else if(col==2*k){
				if(fila==-2*k) pos=4;
				else if(fila==-k) pos=5;
				else if(fila==0) pos=6;
				else if(fila==k) pos=7;
				else if(fila==2*k) pos=8;
			}
			else if(col==3*k){
				if(fila==-3*k) pos=9;
				else if(fila==-2*k) pos=10;
				else if(fila==-k) pos=11;
				else if(fila==0) pos=12;
				else if(fila==k) pos=13;
				else if(fila==2*k) pos=14;
				else if(fila==3*k) pos=15;
			}
		break;
		case suroeste:
			k=-1;
		case noreste:
			if(fila==0){
				if(col==k) pos=3;
				else if(col==2*k) pos=8;
				else if(col==3*k) pos=15;
			}
			else if(fila==-k){
				if(col==0) pos=1;
				else if(col==k) pos=2;
				else if(col==2*k) pos=7;
				else if(col==3*k) pos=14;
			}
			else if(fila==-2*k){
				if(col==0) pos=4;
				else if(col==k) pos=5;
				else if(col==2*k) pos=6;
				else if(col==3*k) pos=13;
			}
			else if(fila==-3*k){
				if(col==0) pos=9;
				else if(col==k) pos=10;
				else if(col==2*k) pos=11;
				else if(col==3*k) pos=12;
			}
			 
		break;
		case noroeste:
			k=-1;
		case sureste:
			if(fila==0){
				if(col==k) pos=1;
				else if(col==2*k) pos=4;
				else if(col==3*k) pos=9;
			}
			else if(fila==k){
				if(col==0) pos=3;
				else if(col==k) pos=2;
				else if(col==2*k) pos=5;
				else if(col==3*k) pos=10;
			}
			else if(fila==2*k){
				if(col==0) pos=8;
				else if(col==k) pos=7;
				else if(col==2*k) pos=6;
				else if(col==3*k) pos=11;
			}
			else if(fila==3*k){
				if(col==0) pos=15;
				else if(col==k) pos=14;
				else if(col==2*k) pos=13;
				else if(col==3*k) pos=12;
			}
		break;
	}
	return pos;
}

void ComportamientoAuxiliar::GetPaths(int f, int c, const Sensores & sensores, vector<pair<int,int>> & camino){
	
	int k=1;
	static vector<unsigned char> v;
	static int tiempo=1000;

	switch(sensores.nivel){
		case 0:
			v={'C','X'};
		break;
		case 1:
			v={'C','S','X'};
		break;
	}

	

	switch (sensores.rumbo){
		case sur:
			k=-1;
		case norte:
		
			if(CasillaDeseada(sensores,2,v)) camino.push_back(make_pair(-k,0));
			if(CasillaDeseada(sensores,1,v)) camino.push_back(make_pair(-k,-k));
			if(CasillaDeseada(sensores,3,v)) camino.push_back(make_pair(-k,k));

		break;	
		case oeste:
			k=-1;
		case este:
			if(CasillaDeseada(sensores,2,v)) camino.push_back(make_pair(0,k));
			if(CasillaDeseada(sensores,1,v)) camino.push_back(make_pair(-k,k));
			if(CasillaDeseada(sensores,3,v)) camino.push_back(make_pair(k,k));

		break;
		case suroeste:
			k=-1;
		case noreste:
			if(CasillaDeseada(sensores,2,v)) camino.push_back(make_pair(-k,k));
			if(CasillaDeseada(sensores,1,v)) camino.push_back(make_pair(-k,0));
			if(CasillaDeseada(sensores,3,v)) camino.push_back(make_pair(0,k));

		break;
		case noroeste:
			k=-1;
		case sureste:
			if(CasillaDeseada(sensores,2,v)) camino.push_back(make_pair(k,k));
			if(CasillaDeseada(sensores,1,v)) camino.push_back(make_pair(0,k));
			if(CasillaDeseada(sensores,3,v)) camino.push_back(make_pair(k,0));

		break;
	}

}

int ComportamientoAuxiliar::LessFreq(const Sensores & sensores){
	vector<pair<int,int>> casillas_camino;
	int f=sensores.posF;
	int c=sensores.posC;
	
	GetPaths(f,c,sensores,casillas_camino);	//Tengo los pares que son casillas deseadas y viables por alrtura.

	//print(casillas_camino);

	pair <int,int> pos=make_pair(0,0);
	int min_frec=frecuencias[f][c];

	if(casillas_camino.size()==0){
		return 0;
	}

	casillas_camino.push_back(make_pair(0,0)); 

	int x,y;
	for(auto it=casillas_camino.begin(); it!=casillas_camino.end(); it++){
		x=it->first;
		y=it->second;
		if(frecuencias[f+x][c+y]<min_frec){
			min_frec=frecuencias[f+x][c+y];
			pos=*it;
		}
	}

	return GetPos(pos.first,pos.second,sensores.rumbo);
}

int ComportamientoAuxiliar::Andar(const Sensores & sensores){

	if(!zap){
		if(sensores.superficie[1]=='D') return 1;
		else if (sensores.superficie[2]=='D') return 2;
		else if (sensores.superficie[3]=='D') return 3;
	}

	int pos=LessFreq(sensores);
	return pos;
}

void ComportamientoAuxiliar::SituarSensorEnMapa(vector<vector<unsigned char>> &m, vector<vector<unsigned char>> &a, Sensores sensores)
{
	int fila=sensores.posF;
	int col=sensores.posC;
	m[fila][col]=sensores.superficie[0];
	a[fila][col]=sensores.cota[0];

	int param=-1;
	int counter=1;

	switch (sensores.rumbo)
	{
		case sur:
			param = 1;
		case norte:
			for(int i=1;i<=3;i++){
				for(int j=-i; j<=i; j++){
					m[fila+param*i][col-param*j]=sensores.superficie[counter];
					a[fila+param*i][col-param*j]=sensores.cota[counter];
					counter++;
				}
			}
		break;
		case oeste:
			param=1;
		case este:
			
			for(int i=1;i<=3;i++){
				for(int j=-i; j<=i; j++){
					m[fila-param*j][col-param*i]=sensores.superficie[counter];
					a[fila-param*j][col-param*i]=sensores.cota[counter];
					counter++;
				}
			}
		break;
		case suroeste:
			param=1;
		case noreste:
			m[fila+param][col]=sensores.superficie[1];
			m[fila+2*param][col]=sensores.superficie[4];
			m[fila+3*param][col]=sensores.superficie[9];
			m[fila][col-param]=sensores.superficie[3];
			m[fila+param][col-param]=sensores.superficie[2];
			m[fila+2*param][col-param]=sensores.superficie[5];
			m[fila+3*param][col-param]=sensores.superficie[10];
			m[fila][col-2*param]=sensores.superficie[8];
			m[fila+param][col-2*param]=sensores.superficie[7];
			m[fila+2*param][col-2*param]=sensores.superficie[6];
			m[fila+3*param][col-2*param]=sensores.superficie[11];
			m[fila][col-3*param]=sensores.superficie[15];
			m[fila+param][col-3*param]=sensores.superficie[14];
			m[fila+2*param][col-3*param]=sensores.superficie[13];
			m[fila+3*param][col-3*param]=sensores.superficie[12];

			a[fila+param][col]=sensores.cota[1];
			a[fila+2*param][col]=sensores.cota[4];
			a[fila+3*param][col]=sensores.cota[9];
			a[fila][col-param]=sensores.cota[3];
			a[fila+param][col-param]=sensores.cota[2];
			a[fila+2*param][col-param]=sensores.cota[5];
			a[fila+3*param][col-param]=sensores.cota[10];
			a[fila][col-2*param]=sensores.cota[8];
			a[fila+param][col-2*param]=sensores.cota[7];
			a[fila+2*param][col-2*param]=sensores.cota[6];
			a[fila+3*param][col-2*param]=sensores.cota[11];
			a[fila][col-3*param]=sensores.cota[15];
			a[fila+param][col-3*param]=sensores.cota[14];
			a[fila+2*param][col-3*param]=sensores.cota[13];
			a[fila+3*param][col-3*param]=sensores.cota[12];
			
		break;
		case noroeste:
			param=1;
		case sureste:
			m[fila][col-param]=sensores.superficie[1];
			m[fila][col-2*param]=sensores.superficie[4];
			m[fila][col-3*param]=sensores.superficie[9];
			m[fila-param][col]=sensores.superficie[3];
			m[fila-param][col-param]=sensores.superficie[2];
			m[fila-param][col-2*param]=sensores.superficie[5];
			m[fila-param][col-3*param]=sensores.superficie[10];
			m[fila-2*param][col]=sensores.superficie[8];
			m[fila-2*param][col-param]=sensores.superficie[7];
			m[fila-2*param][col-2*param]=sensores.superficie[6];
			m[fila-2*param][col-3*param]=sensores.superficie[11];
			m[fila-3*param][col]=sensores.superficie[15];
			m[fila-3*param][col-param]=sensores.superficie[14];
			m[fila-3*param][col-2*param]=sensores.superficie[13];
			m[fila-3*param][col-3*param]=sensores.superficie[12];

			a[fila][col-param]=sensores.cota[1];
			a[fila][col-2*param]=sensores.cota[4];
			a[fila][col-3*param]=sensores.cota[9];
			a[fila-param][col]=sensores.cota[3];	
			a[fila-param][col-param]=sensores.cota[2];
			a[fila-param][col-2*param]=sensores.cota[5];
			a[fila-param][col-3*param]=sensores.cota[10];
			a[fila-2*param][col]=sensores.cota[8];
			a[fila-2*param][col-param]=sensores.cota[7];
			a[fila-2*param][col-2*param]=sensores.cota[6];
			a[fila-2*param][col-3*param]=sensores.cota[11];
			a[fila-3*param][col]=sensores.cota[15];
			a[fila-3*param][col-param]=sensores.cota[14];
			a[fila-3*param][col-2*param]=sensores.cota[13];
			a[fila-3*param][col-3*param]=sensores.cota[12];
		break;
	}
	
}

/***************************************/
//Funciones auxiliares
/***************************************/

void ComportamientoAuxiliar::ActualizarFrecs(int f, int c, Orientacion rumbo){

	//TOOD: no sumar a las casillas meta
	int k=1;
	switch (rumbo)
	{
		case sur:
			k=-1;
		case norte:
			for(int i=0; i<=3; i++){
				for(int j=-i; j<=i; j++){
					frecuencias[f-k*i][c+j]+=selector(mapaResultado[f-k*i][c+j]);
				}
			}
		break;
		case oeste:
			k=-1;
		case este:
			for(int i=0; i<=3; i++){
				for(int j=-i; j<=k; j++){
					frecuencias[f+j][c+k*i]+=selector(mapaResultado[f+j][c+k*i]);
				}
			}
		break;
		case suroeste:
			k=-1;
		case noreste:
			for(int i=0; i<=3; i++){
				for(int j=0; j<=3;j++){
					frecuencias[f-k*i][c+k*j]+=selector(mapaResultado[f-k*i][c+k*j]);
				}
			}
		break;
		case noroeste:
			k=-1;
		case sureste:
			for(int i=0; i<=3; i++){
				for(int j=0; j<=3;j++){
					frecuencias[f+k*i][c+k*j]+=selector(mapaResultado[f+k*i][c+k*j]);
				}
			}
		break;
	}
}

int ComportamientoAuxiliar::selector(char casilla){
	int val;

	switch(casilla){
		case 'C' or 'S':
			val=2;
		break;
		case 'X':
			val=0;
		break;
		case 'T':
			val=3;
		break;
		case 'D':
			val=1;
		break;
		case 'M':
			val=6;
		break;
		case 'P':
			val=6;
		break;
		case 'A':
			val=4;
		break;
		case 'B':
			val=3;
		break;
	}

	return val;
}

void ComportamientoAuxiliar::ResetFrec(int f, int c, int k){
	if(k==-1){
		for(int i=0; i<frecuencias.size(); i++){
			for(int j=0; j<frecuencias[0].size(); j++){
				frecuencias[f+i][c+j]=0;
			}
		}
	}
	else{
		for(int i=-k; i<=k; i++){
			for(int j=-k; j<=k; j++){
				frecuencias[f+i][c+j]=0;
			}
		}
	}
	
}

bool ComportamientoAuxiliar::ViablePorAlturaA(int dif)
{
	return abs(dif)<=1;
}

bool ComportamientoAuxiliar::CasillaDeseada(const Sensores &sensores, int casilla, const vector<unsigned char> & deseadas)
{
	if(IsIn(deseadas,sensores.superficie[casilla]) and ViablePorAlturaA(sensores.cota[casilla]-sensores.cota[0]))
		return true;
	else
		return false;
}