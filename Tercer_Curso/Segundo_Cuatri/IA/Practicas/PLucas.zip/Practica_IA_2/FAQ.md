# Frequently Asked Questions

Algunos problemas comunes hasta el momento con el uso de Github o la realización de la práctica.

## Relacionados con la Práctica 2


