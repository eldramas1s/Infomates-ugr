#ifndef LOMO_H
#define LOMO_H

#include "obj3dlib.hpp"

class LomoPerro : public Objeto3D {
private:
  /* data */
public:
  LomoPerro();
  ~LomoPerro();

};

#endif
