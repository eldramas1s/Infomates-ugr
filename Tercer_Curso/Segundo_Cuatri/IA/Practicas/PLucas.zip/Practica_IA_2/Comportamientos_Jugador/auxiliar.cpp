#include "../Comportamientos_Jugador/auxiliar.hpp"
#include <iostream>
#include "motorlib/util.h"

Action ComportamientoAuxiliar::think(Sensores sensores)
{
	Action accion = IDLE;

	switch (sensores.nivel)
	{
	case 0:
		//accion = ComportamientoAuxiliarNivel_0 (sensores);
		break;
	case 1:
		// accion = ComportamientoAuxiliarNivel_1 (sensores);
		break;
	case 2:
		// accion = ComportamientoAuxiliarNivel_2 (sensores);
		break;
	case 3:
		// accion = ComportamientoAuxiliarNivel_3 (sensores);
		break;
	case 4:
		// accion = ComportamientoAuxiliarNivel_4 (sensores);
		break;
	}

	return accion;
}

int ComportamientoAuxiliar::interact(Action accion, int valor)
{
	return 0;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_0(Sensores sensores)
{
	SituarSensorEnMapa(mapaResultado,mapaCotas,sensores);
	Action action;

	frecuencias[sensores.posF][sensores.posC]++; //Actualizo la matriz de frecuencias

	if(sensores.superficie[0]=='D') zap=1;
	if(sensores.superficie[0]=='X')
		action=IDLE;
	
	else if(giro45izq!=0){
		if (sensores.superficie[2]=='X') {
			action = WALK;
			giro45izq = 0;
		}
		else{
			action = TURN_SR;
			giro45izq--;
		}
	}
	else if(giro180!=0){
		action=TURN_SR;
		giro180--;
	}
	else if(sensores.choque){
		action=TURN_SR;
		giro180=3;
	}
	else{
		int pos=Andar(sensores);
		if(pos == 2){
			action = WALK;
		}
		else if(pos == 0)
			action = TURN_SR;
		else {
			action = TURN_SR;
			if(pos == 1){
				giro45izq = 6;
			}
		}

	}
	return action;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_1(Sensores sensores)
{
	return IDLE;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_2(Sensores sensores)
{
	return IDLE;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_3(Sensores sensores)
{
	return IDLE;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_4(Sensores sensores)
{
	return IDLE;
}


bool ComportamientoAuxiliar::CasillaDeseada(const Sensores &sensores, int casilla, const vector<unsigned char> & deseadas)
{
	if(IsIn(deseadas,sensores.superficie[casilla]) and ViablePorAlturaA(sensores.cota[casilla]-sensores.cota[0]))
		return true;
	else
		return false;
}

bool ComportamientoAuxiliar::ViablePorAlturaA(int dif)
{
	return abs(dif)<=1;
}

int ComportamientoAuxiliar::GetPos(int fila,int col, Orientacion rumbo){
	int pos=0;
	int k=-1;
	switch (rumbo)
	{
		case sur:
			k=1;
		case norte:
			if(abs(fila)==1) pos = k*2*fila+col;
			else if(abs(fila)==2) pos = k*3*fila+col;
			else if(abs(fila)==3) pos = k*4*fila+col;
		break;
		case este:
			k=1;
		case oeste:
			if(abs(col)==1) pos = k*2*col+fila;
			else if(abs(col)==2) pos = k*3*col+fila;
			else if(abs(col)==3) pos = k*4*col+fila;
		break;
		case suroeste:
			k=1;
		case noreste:
			if(abs(fila)>=col) pos = fila*fila - k*col;
			else if(fila==0 and col==-k) pos = 3;
			else if(fila==0 and col==-k*2) pos = 8;
			else if(fila==0 and col==-3*k) pos = 15;
			else if(fila==k and col==-2*k) pos = 7;
			else if(fila==k and col==-3*k) pos = 14;
			else if(fila==2*k and col==-3*k) pos=13; 
		break;
		case sureste:
			k=1;
		case noroeste:
			if(abs(col)>=fila) pos= col*col+k*fila;
			else if(fila==k and col==0) pos = 3;
			else if(fila==2*k and col==0) pos = 8;
			else if(fila==3*k and col==0) pos = 15;
			else if(fila==2*k and col==k) pos = 7;
			else if(fila==3*k and col==k) pos = 14;
			else if(fila==2*k and col==3*k) pos=13;
		break;
	}
	return pos;
}

void ComportamientoAuxiliar::ResetFrec(int f, int c, int k){
	
	//this->frecuencias.resize(mapaResultado.size(), vector<int>(mapaResultado[0].size(), 0));

	/* OTRA OPCION //?Cual es mejor?*/
	for(int i=f-k; i<=f+k; i++){
		for(int j=c-k; j<c+k; j++){
			frecuencias[i][j]=0;
		}
	}
	
}

void ComportamientoAuxiliar::GetPaths(int f, int c, const Sensores & sensores, vector<pair<int,int>> & camino){
	
	int k=-1, i=1;
	
	static vector<unsigned char> v={'C','X'};

	switch (sensores.rumbo){
		case sur:
			k=1;
		case norte:
			for(int j=-1; j<=1; j++){
				if(CasillaDeseada(sensores,i,v)){
					// cout << CasillaDeseada(sensores,zap,i,v) << endl;
					camino.push_back(make_pair(k, j)); 
				}
				i++;
			}
			
		break;
		case este:
			k=1;
		case oeste:
			for(int j=-1; j<=1; j++){
				if(CasillaDeseada(sensores,i,v)){
					pair<int,int> p=make_pair(j, k);
					// cout << "j: " << j << " k: " << k << endl;
					// cout << CasillaDeseada(sensores,zap,i,v) << endl;
					camino.push_back(make_pair(j, k));
				}
				i++;
			}

		break;
		case suroeste:
			k=1;
		case noreste:
			if(CasillaDeseada(sensores,1,v)) camino.push_back(make_pair(k, 0));
			if(CasillaDeseada(sensores,2,v)) camino.push_back(make_pair(k, -k));
			if(CasillaDeseada(sensores,3,v)) camino.push_back(make_pair(0, -k));

		break;
		case noroeste:
			k=1;
		case sureste:
			if(CasillaDeseada(sensores,1,v)) camino.push_back(make_pair(0, -k));
			if(CasillaDeseada(sensores,2,v)) camino.push_back(make_pair(-k, -k));
			if(CasillaDeseada(sensores,3,v)) camino.push_back(make_pair(-k, 0));

		break;
	}


}

int ComportamientoAuxiliar::LessFreq(const Sensores & sensores){

	vector<pair<int,int>> casillas_camino;
	int f=sensores.posF;
	int c=sensores.posC;
	
	GetPaths(f,c,sensores,casillas_camino);	//Tengo los pares que son casillas deseadas y viables por alrtura.

	print(casillas_camino);

	pair <int,int> pos;
	int min_frec=999999;

	if(casillas_camino.size()==0){
		return 0;
	}

	for(auto it=casillas_camino.begin(); it!=casillas_camino.end(); it++){
		int x=it->first;
		int y=it->second;
		if(frecuencias[f+x][c+y]<min_frec or min_frec==999999){
			min_frec=frecuencias[f+x][c+y];
			pos=*it;
			cout << "Pos: " << pos.first << " " << pos.second << endl;
			cout << "Min: " << min_frec << endl;
		}
	}

	return GetPos(pos.first,pos.second,sensores.rumbo);
	
}

//!Auxiliar tiene ciclos sencillos
int ComportamientoAuxiliar::Andar(const Sensores & sensores){

	static int movimientos_no2=0;
	static int moves=0;

	//Refrescamos la memoria del agente
	if(movimientos_no2>8){
		movimientos_no2=0;
		ResetFrec(sensores.posF,sensores.posC);
	}

	if(moves>50){
		moves=0;
		ResetFrec(sensores.posF,sensores.posC);
	}

	if(!zap){
		if(sensores.superficie[1]=='D' and ViablePorAlturaA(sensores.cota[1]-sensores.cota[0])) return 1;
		else if(sensores.superficie[2]=='D' and ViablePorAlturaA(sensores.cota[2]-sensores.cota[0])) return 2;
		else if(sensores.superficie[3]=='D' and ViablePorAlturaA(sensores.cota[3]-sensores.cota[0])) return 3;
	}

	
	int pos=LessFreq(sensores);

	//Actualizamos los contadores de movimientos
	if(pos!=2){
		movimientos_no2++;
	}
	else{
		movimientos_no2=0;
	}

	moves++;
	return pos;
	
}

void ComportamientoAuxiliar::SituarSensorEnMapa(vector<vector<unsigned char>> &m, vector<vector<unsigned char>> &a, Sensores sensores)
{
	int fila=sensores.posF;
	int col=sensores.posC;
	m[fila][col]=sensores.superficie[0];
	a[fila][col]=sensores.cota[0];

	int param=-1;
	int counter=1;

	switch (sensores.rumbo)
	{
		case sur:
			param = 1;
		case norte:
			for(int i=1;i<=3;i++){
				for(int j=-i; j<=i; j++){
					m[fila+param*i][col-param*j]=sensores.superficie[counter];
					a[fila+param*i][col-param*j]=sensores.cota[counter];
					counter++;
				}
			}
		break;
		case oeste:
			param=1;
		case este:
			
			for(int i=1;i<=3;i++){
				for(int j=-i; j<=i; j++){
					m[fila-param*j][col-param*i]=sensores.superficie[counter];
					a[fila-param*j][col-param*i]=sensores.cota[counter];
					counter++;
				}
			}
		break;
		case suroeste:
			param=1;
		break;
		case noreste:
			
			for( int i=0; i<=3; i++){
				for (int j=0; j<=3;j++){
					if(i>=j){
						m[fila+param*i][col-param*j]=sensores.superficie[i*i+j];
						a[fila+param*j][col-param*i]=sensores.superficie[i*i+j];
					}
				}
			}

			m[fila][col-param]=sensores.superficie[3];
			m[fila][col-2*param]=sensores.superficie[8];
			m[fila][col-3*param]=sensores.superficie[15];
			m[fila+param][col-3*param]=sensores.superficie[7];
			m[fila+2*param][col-3*param]=sensores.superficie[13];
			m[fila+param][col-3*param]=sensores.superficie[14];
			
		break;
		case noroeste:
			param=1;
		break;
		case sureste:
			for( int i=0; i<=3; i++){
				for (int j=0; j<=3;j++){
					if(j>=i){
						m[fila-param*i][col-param*j]=sensores.superficie[j*j+i];
						a[fila-param*i][col-param*j]=sensores.superficie[j*j+i];
					}
				}
			}
			m[fila-param][col]=sensores.superficie[3];
			m[fila-2*param][col]=sensores.superficie[8];
			m[fila-3*param][col]=sensores.superficie[15];
			m[fila-2*param][col-param]=sensores.superficie[7];
			m[fila-3*param][col-2*param]=sensores.superficie[13];
			m[fila-3*param][col-param]=sensores.superficie[14];
		break;
	}
	
}