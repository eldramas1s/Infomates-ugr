#include <iostream>
#include "../Comportamientos_Jugador/rescatador.hpp"
#include "motorlib/util.h"

Action ComportamientoRescatador::think(Sensores sensores)
{
	Action accion = IDLE;

	switch (sensores.nivel)
	{
	case 0:
		accion = ComportamientoRescatadorNivel_0 (sensores);
		break;
	case 1:
		//accion = ComportamientoRescatadorNivel_1 (sensores);
		break;
	case 2:
		// accion = ComportamientoRescatadorNivel_2 (sensores);
		break;
	case 3:
		// accion = ComportamientoRescatadorNivel_3 (sensores);
		break;
	case 4:
		// accion = ComportamientoRescatadorNivel_4 (sensores);
		break;
	}

	return accion;
}

int ComportamientoRescatador::interact(Action accion, int valor)
{
	return 0;
}

Action ComportamientoRescatador::ComportamientoRescatadorNivel_0(Sensores sensores)
{
	// cout << "Frente:" << frecuencias[sensores.posF-1][sensores.posC] << endl;
	
	// cout << "MI frec: " << frecuencias[sensores.posF][sensores.posC] << endl; 
	SituarSensorEnMapa(mapaResultado, mapaCotas, sensores);

	//Actualizo la matriz de frecuencias
	if(frecuencias[sensores.posF][sensores.posC]>=5){
		ResetFrec(sensores.posF,sensores.posC,3);
	}

	frecuencias[sensores.posF][sensores.posC]++;

	Action action;

	
	
	if(sensores.superficie[0]=='D') {
		zap=1;
	}
	if(sensores.superficie[0]=='X') {
		action=IDLE;
	}
	else if(sensores.choque){
		action=TURN_L;
	}
	else if(giro180_izq){
		action = TURN_L;
		giro180_izq = false;
	}
	else if(giro45izq!=0){
		// cout << "Hago giro" << endl;
		action = TURN_SR;
		giro45izq--;
	}
	else if(HayAuxiliar(sensores.agentes,2)){
		action = TURN_L;
		giro180_izq = true;
	}
	else if(run){
		action=RUN;
		run=false;
	}
	else{

		int pos=Andar(sensores);
		
		switch (pos)
		{	
			case 0:
				action = TURN_L;
			break;
			case 1:
				giro45izq = 1;
				action = TURN_L;
			break;
			case 2:
				action = WALK;
			break;
			case 3:
				action = TURN_SR;
				break;
			case 4: 
				giro45izq = 1;
				action = TURN_L;
				run=true;
				break;
			case 6:
				action = RUN;
				break;
			case 8:
				action = TURN_SR;
				run=true;
			break;
		}
		
	}
	last_action = action;
	return action;
}

Action ComportamientoRescatador::ComportamientoRescatadorNivel_1(Sensores sensores)
{
	SituarSensorEnMapa(mapaResultado, mapaCotas, sensores);
	Action action;
	
	last_action = action;
	return action;
}

Action ComportamientoRescatador::ComportamientoRescatadorNivel_2(Sensores sensores)
{
	return IDLE;
}

Action ComportamientoRescatador::ComportamientoRescatadorNivel_3(Sensores sensores)
{
	return IDLE;
}

Action ComportamientoRescatador::ComportamientoRescatadorNivel_4(Sensores sensores)
{
	return IDLE;
}


/************************************/
// Métodos auxiliares
/************************************/

int ComportamientoRescatador::LessFreq(const Sensores & sensores){
	vector<pair<int,int>> casillas_camino;
	int f=sensores.posF;
	int c=sensores.posC;
	
	GetPaths(f,c,sensores,casillas_camino);	//Tengo los pares que son casillas deseadas y viables por alrtura.

	print(casillas_camino);

	pair <int,int> pos=make_pair(0,0);
	int min_frec=frecuencias[f][c];

	if(casillas_camino.size()==0){
		return 0;
	}

	casillas_camino.push_back(pos);

	int x,y;
	for(auto it=casillas_camino.begin(); it!=casillas_camino.end(); it++){
		x=it->first;
		y=it->second;
		if(frecuencias[f+x][c+y]<min_frec){
			min_frec=frecuencias[f+x][c+y];
			pos=*it;
			// cout << "Pos: " << pos.first << " " << pos.second << endl;
			// cout << "Min: " << min_frec << endl;
		}
	}

	return GetPos(pos.first,pos.second,sensores.rumbo);
}

void ComportamientoRescatador::GetPaths(int f, int c, const Sensores & sensores, vector<pair<int,int>> & camino){
	
	int k=-1, i=1;
	
	//?Cambiar por un switch dependiendo del nivel?

	static vector<unsigned char> v={'C','X'};

	switch (sensores.rumbo){
		case sur:
			k=1;
		case norte:
			for(int j=-1; j<=1; j++){
				if(CasillaDeseada(sensores,i,v)){
					camino.push_back(make_pair(k, j)); 
				}
				i++;
			}
			
			//Si tengo zapatillas
			if(zap){
				for(int j=-2; j<=2; j+=2){
					if(CasillaDeseada(sensores,i,v)){
						camino.push_back(make_pair(k*2, j));
					}
					i+=2;
				}
			}
		break;
		case este:
			k=1;
		case oeste:
			for(int j=-1; j<=1; j++){
				if(CasillaDeseada(sensores,i,v)){
					pair<int,int> p=make_pair(j, k);
					camino.push_back(make_pair(j, k));
				}
				i++;
			}

			//Si tengo zapatillas
			if(zap){
				for(int j=-2; j<=2; j+=2){
					if(CasillaDeseada(sensores,i,v)){
						camino.push_back(make_pair(j, k*2));
					}
					i+=2;
				}
			}
		break;
		case suroeste:
			k=1;
		case noreste:
			if(CasillaDeseada(sensores,1,v)) camino.push_back(make_pair(k, 0));
			if(CasillaDeseada(sensores,2,v)) camino.push_back(make_pair(k, -k));
			if(CasillaDeseada(sensores,3,v)) camino.push_back(make_pair(0, -k));

			//Si tengo zapatillas
			if(zap){
				if(CasillaDeseada(sensores,4,v)) camino.push_back(make_pair(2*k, 0));
				if(CasillaDeseada(sensores,6,v)) camino.push_back(make_pair(2*k, -2*k));
				if(CasillaDeseada(sensores,8,v)) camino.push_back(make_pair(0, 2*k));
			}
		break;
		case noroeste:
			k=1;
		case sureste:
			if(CasillaDeseada(sensores,1,v)) camino.push_back(make_pair(0, -k));
			if(CasillaDeseada(sensores,2,v)) camino.push_back(make_pair(-k, -k));
			if(CasillaDeseada(sensores,3,v)) camino.push_back(make_pair(-k, 0));

			//Si tengo zapatillas
			if(zap){
				if(CasillaDeseada(sensores,4,v)) camino.push_back(make_pair(-2*k, 0));
				if(CasillaDeseada(sensores,6,v)) camino.push_back(make_pair(-2*k, -2*k));
				if(CasillaDeseada(sensores,8,v)) camino.push_back(make_pair(0, -2*k));
			}
		break;
	}


}

int ComportamientoRescatador::GetPos(int fila,int col, Orientacion rumbo){
	int pos=0;
	int k=-1;
	switch (rumbo)
	{
		case sur:
			k=1;
		case norte:
			if(abs(fila)==1) pos = k*2*fila+col;
			else if(abs(fila)==2) pos = k*3*fila+col;
			else if(abs(fila)==3) pos = k*4*fila+col;
		break;
		case este:
			k=1;
		case oeste:
			if(abs(col)==1) pos = k*2*col+fila;
			else if(abs(col)==2) pos = k*3*col+fila;
			else if(abs(col)==3) pos = k*4*col+fila;
		break;
		case suroeste:
			k=1;
		case noreste:
			if(abs(fila)>=col) pos = fila*fila - k*col;
			else if(fila==0 and col==-k) pos = 3;
			else if(fila==0 and col==-k*2) pos = 8;
			else if(fila==0 and col==-3*k) pos = 15;
			else if(fila==k and col==-2*k) pos = 7;
			else if(fila==k and col==-3*k) pos = 14;
			else pos=13; 
		break;
		case sureste:
			k=1;
		case noroeste:
			if(abs(col)>=fila) pos= col*col+k*fila;
			else if(fila==k and col==0) pos = 3;
			else if(fila==2*k and col==0) pos = 8;
			else if(fila==3*k and col==0) pos = 15;
			else if(fila==2*k and col==k) pos = 7;
			else if(fila==3*k and col==k) pos = 14;
			else pos=13;
		break;
	}
	return pos;
}

int ComportamientoRescatador::Andar(const Sensores & sensores){

	if(!zap){
		if(sensores.superficie[1]=='D') return 1;
		else if (sensores.superficie[2]=='D') return 2;
		else if (sensores.superficie[3]=='D') return 3;
	}

	int pos=LessFreq(sensores);

	ActualizarFrecuencias(sensores.posF, sensores.posC, sensores.rumbo);

	// cout << pos << endl;
	return pos;
}

void ComportamientoRescatador::ActualizarFrecuencias(int f, int c, Orientacion rumbo){

	int k=1;
	switch (rumbo){
		case sur:
			k=-1;
		case norte:
			for(int i=1; i<=3; i++){
				for (int j=-i; j<=i; j++){
					frecuencias[f-k*i][c+j]++;
				}
			}
		break;
		case este:
			k=-1;
		case oeste:
			for(int i=1; i<=3; i++){
				for (int j=-i; j<=i; j++){
					frecuencias[f+j][c-k*i]++;
				}
			}
		break;
		case suroeste:
			k=-1;
		case noreste:
			for( int i=0; i<=3; i++){
				for (int j=0; j<=3;j++){
					if(j!=0 or i!=0)
						frecuencias[f-k*i][c+k*j]++;
				}
			}
		break;
		case sureste:
			k=-1;
		case noroeste:
			for( int i=0; i<=3; i++){
				for (int j=0; j<=3;j++){
					if(j!=0 or i!=0)	
						frecuencias[f-k*i][c-k*j]++;
				}
			}
		break;
	}
}
//Funciones listas

bool ComportamientoRescatador::ViablePorAlturaR(int dif)
{
	if(abs(dif)<=1 or (zap and abs(dif)<=2))
		return true;
	else 
		return false;
}

bool ComportamientoRescatador::HayAuxiliar(const vector<unsigned char> & ags,int casilla)
{
	return ags[casilla]=='a';
}

void ComportamientoRescatador::ResetFrec(int f, int c, int k){
	if(k==-1){
		for(int i=0; i<frecuencias.size(); i++){
			for(int j=0; j<frecuencias[0].size(); j++){
				frecuencias[i][j]=0;
			}
		}
	}
	else{
		for(int i=f-k; i<=f+k; i++){
			for(int j=c-k; j<c+k; j++){
				frecuencias[i][j]=0;
			}
		}
	}
	
	
}

bool ComportamientoRescatador::CasillaDeseada(const Sensores &sensores, int casilla, const vector<unsigned char> & deseadas)
{
	if(IsIn(deseadas,sensores.superficie[casilla]) and ViablePorAlturaR(sensores.cota[casilla]-sensores.cota[0])){
			return true;
	}
	else
		return false;
}

void ComportamientoRescatador::SituarSensorEnMapa(vector<vector<unsigned char>> &m, vector<vector<unsigned char>> &a, Sensores sensores)
{
	int fila=sensores.posF;
	int col=sensores.posC;
	m[fila][col]=sensores.superficie[0];
	a[fila][col]=sensores.cota[0];

	int param=-1;
	int counter=1;

	switch (sensores.rumbo)
	{
		case sur:
			param = 1;
		case norte:
			for(int i=1;i<=3;i++){
				for(int j=-i; j<=i; j++){
					m[fila+param*i][col-param*j]=sensores.superficie[counter];
					a[fila+param*i][col-param*j]=sensores.cota[counter];
					counter++;
				}
			}
		break;
		case oeste:
			param=1;
		case este:
			
			for(int i=1;i<=3;i++){
				for(int j=-i; j<=i; j++){
					m[fila-param*j][col-param*i]=sensores.superficie[counter];
					a[fila-param*j][col-param*i]=sensores.cota[counter];
					counter++;
				}
			}
		break;
		case suroeste:
			param=1;
		break;
		case noreste:
			
			for( int i=0; i<=3; i++){
				for (int j=0; j<=3;j++){
					if(i>=j){
						m[fila+param*i][col-param*j]=sensores.superficie[i*i-param*j];
						a[fila+param*i][col-param*j]=sensores.superficie[i*i-param*j];
					}
				}
			}

			m[fila][col-param]=sensores.superficie[3];
			m[fila][col-2*param]=sensores.superficie[8];
			m[fila][col-3*param]=sensores.superficie[15];
			m[fila+param][col-3*param]=sensores.superficie[7];
			m[fila+2*param][col-3*param]=sensores.superficie[13];
			m[fila+param][col-3*param]=sensores.superficie[14];

			a[fila][col-param]=sensores.cota[3];
			a[fila][col-2*param]=sensores.cota[8];
			a[fila][col-3*param]=sensores.cota[15];
			a[fila+param][col-3*param]=sensores.cota[7];
			a[fila+2*param][col-3*param]=sensores.cota[13];
			a[fila+param][col-3*param]=sensores.cota[14];
			
		break;
		case noroeste:
			param=1;
		break;
		case sureste:
			for( int i=0; i<=3; i++){
				for (int j=0; j<=3;j++){
					if(j>=i){
						m[fila-param*i][col-param*j]=sensores.superficie[j*j-param*i];
						a[fila+param*i][col-param*j]=sensores.cota[j*j-param*i];
					}
				}
			}
			m[fila-param][col]=sensores.superficie[3];
			m[fila-2*param][col]=sensores.superficie[8];
			m[fila-3*param][col]=sensores.superficie[15];
			m[fila-2*param][col-param]=sensores.superficie[7];
			m[fila-3*param][col-2*param]=sensores.superficie[13];
			m[fila-3*param][col-param]=sensores.superficie[14];

			a[fila-param][col]=sensores.cota[3];
			a[fila-2*param][col]=sensores.cota[8];
			a[fila-3*param][col]=sensores.cota[15];
			a[fila-2*param][col-param]=sensores.cota[7];
			a[fila-3*param][col-2*param]=sensores.cota[13];
			a[fila-3*param][col-param]=sensores.cota[14];
		break;
	}
	
}