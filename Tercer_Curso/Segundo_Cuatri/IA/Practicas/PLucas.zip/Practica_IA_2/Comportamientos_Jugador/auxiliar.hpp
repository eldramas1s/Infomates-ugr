#ifndef COMPORTAMIENTOAUXILIAR_H
#define COMPORTAMIENTOAUXILIAR_H

#include <chrono>
#include <time.h>
#include <thread>
#include <vector>
#include <iostream>

#include "comportamientos/comportamiento.hpp"

class ComportamientoAuxiliar : public Comportamiento
{

public:
  ComportamientoAuxiliar(unsigned int size = 0) : Comportamiento(size)
  {
    // Inicializar Variables de Estado Niveles 0,1,4
    last_action = IDLE;
    giro45izq = 0;
    zap = false;
    giro180=0;
    frecuencias.resize(mapaResultado.size(), vector<int>(mapaResultado[0].size(), 0));
    
  }
  ComportamientoAuxiliar(std::vector<std::vector<unsigned char>> mapaR, std::vector<std::vector<unsigned char>> mapaC) : Comportamiento(mapaR,mapaC)
  {
    // Inicializar Variables de Estado Niveles 2,3
  }
  ComportamientoAuxiliar(const ComportamientoAuxiliar &comport) : Comportamiento(comport) {}
  ~ComportamientoAuxiliar() {}

  Action think(Sensores sensores);

  int interact(Action accion, int valor);

  Action ComportamientoAuxiliarNivel_0(Sensores sensores);
  Action ComportamientoAuxiliarNivel_1(Sensores sensores);
  Action ComportamientoAuxiliarNivel_2(Sensores sensores);
  Action ComportamientoAuxiliarNivel_3(Sensores sensores);
  Action ComportamientoAuxiliarNivel_4(Sensores sensores);

  /**********************************************************/
  // Métodos auxiliares
  /**********************************************************/

  /**
   * @brief Método auxiliar que determina si la casilla a acceder es viable por altura
   * 
   * @param casilla Lugar a donde se quiere ir
   * @param dif Diferencia de altura entre la casilla actual y casilla
   * @return char Casilla a la que se puede acceder
   */
  bool ViablePorAlturaA(int dif);

  /**
   * @brief Método auxiliar que pinta la visión en los mapas de superficie y altura
   * 
   * @param sensores Sensores del rescatador
   * @param m Mapa de superficie
   * @param a Mapa de altura
   * @post Los mapas de superficie y altura se actualizan con la información de los sensores
   */
  void SituarSensorEnMapa(vector<vector<unsigned char>> &m, vector<vector<unsigned char>> &a, Sensores sensores);

  /**
   * @brief Determina la casilla con menor frecuencia de las delanteras
   * 
   * @param fila fila del agente
   * @param col columna del agente
   * @param sensores sensores del agente
   * @return int casilla de la vision con menor frecuencia de pisada
   */
  int LessFreq(const Sensores &sensores);

  /**
   * @brief Obtiene la posicion sobre el sensor de vision de la casilla de frecuencia
   * 
   * @param fila pila de la casilla
   * @param col columna de la casilla
   * @param rumbo Orientacion del agente
   * 
   * @pre |fila|<=2 and |col|<=2
   * @return int Entero del 1 al 15
   */
  int GetPos(int fila,int col, Orientacion rumbo);

  /**
   * @brief Obtiene por referencia las posiciones sobre la matriz de frecuencias de los caminos posibles
   * 
   * @param f fila del agente
   * @param c columna del agente
   * @param sensores Sensores del agente
   * @param zap booleano que indica si el agente tiene zapatillas
   * @param camino vector con pares de posiciones en la matriz
   */
  void GetPaths(int f, int c, const Sensores & sensores, vector<pair<int,int>> &camino);

  /**
   * @brief Comprueba si la casilla es una de las que queremos y es viable por altura
   * 
   * @param sensores Sensores del agente
   * @param casilla casilla que queremos comprobar
   * 
   * @pre 0 < casilla < 16
   * @return true si la casilla es deseada 
   */
  bool CasillaDeseada(const Sensores & sensores, int casilla, const vector<unsigned char> & deseadas);

  /**
   * @brief Determina el comportamiento del agente
   * 
   * @param sensores Sensores del agente
   * @return int posicion a la que moverse
   */
  int Andar(const Sensores & sensores);
  
  /**
   * @brief Determina si hay existencias de un elemento en un vector
   * 
   * @param v vector 
   * @param x elemento a buscar
   * @return true si el elemento x esta en v.
   */
  bool IsIn(const vector<unsigned char> &v, char x){
    for (auto it=v.begin(); it!=v.end(); it++){
      if(*it==x) return true;
    }
    return false;
  }

  /**
   * @brief Imprime un vector de pares (DEBUG)
   * 
   * @param v vector a imprimir
   */
  void print(const vector<pair<int,int>> &v){
    for (auto it=v.begin(); it!=v.end(); it++){
      cout << '(' << (*it).first << ',' << (*it).second << ')';
    }
  }

  /**
   * @brief Resetea el mapa de frecuencias en un entorno del agente
   * 
   */
  void ResetFrec(int f, int col, int k=3);

private:
  int giro45izq;
  bool zap;
  int last_action;
  int giro180;
  vector<vector<int>> frecuencias; // Mapa de frecuencias de pisadas
  
};

#endif
