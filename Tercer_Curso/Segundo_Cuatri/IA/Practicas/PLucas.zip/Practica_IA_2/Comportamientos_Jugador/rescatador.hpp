#ifndef COMPORTAMIENTORESCATADOR_H
#define COMPORTAMIENTORESCATADOR_H

#include <chrono>
#include <time.h>
#include <thread>
#include <vector>

#include "comportamientos/comportamiento.hpp"

class ComportamientoRescatador : public Comportamiento
{

public:
  ComportamientoRescatador(unsigned int size = 0) : Comportamiento(size)
  {
    // Inicializar Variables de Estado Niveles 0,1
    last_action = IDLE;
    giro45izq = 0;
    zap = false;
    giro180_izq = false;
    frecuencias.resize(mapaResultado.size(), vector<int>(mapaResultado[0].size(), 0));
    run = false;
  }
  ComportamientoRescatador(std::vector<std::vector<unsigned char>> mapaR, std::vector<std::vector<unsigned char>> mapaC) : Comportamiento(mapaR,mapaC)
  {
    // Inicializar Variables de Estado Niveles 2,3
  }
  ComportamientoRescatador(const ComportamientoRescatador &comport) : Comportamiento(comport) {}
  ~ComportamientoRescatador() {}

  Action think(Sensores sensores);

  int interact(Action accion, int valor);

  Action ComportamientoRescatadorNivel_0(Sensores sensores);
  Action ComportamientoRescatadorNivel_1(Sensores sensores);
  Action ComportamientoRescatadorNivel_2(Sensores sensores);
  Action ComportamientoRescatadorNivel_3(Sensores sensores);
  Action ComportamientoRescatadorNivel_4(Sensores sensores);
  

  /**********************************************************/
  // Métodos auxiliares
  /**********************************************************/

  /**
   * @brief Método auxiliar que determina si la casilla a acceder es viable por altura
   * 
   * @param dif Diferencia de altura entre la casilla actual y casilla
   * @return true si la casilla a la que accedemos es viable por altura
   */
  bool ViablePorAlturaR(int dif); 

  /**
   * @brief Método auxiliar que determina si hay un auxiliar en la visión
   * 
   * @param ags Matriz de agentes
   * @return true si hay una auxiliar en un pequeño rago de visión.
   */
  bool HayAuxiliar(const vector<unsigned char> & ags, int casilla);

  /**
   * @brief Método auxiliar que pinta la visión en los mapas de superficie y altura
   * 
   * @param sensores Sensores del rescatador
   * @param m Mapa de superficie
   * @param a Mapa de altura
   * @post Los mapas de superficie y altura se actualizan con la información de los sensores
   */
  void SituarSensorEnMapa(vector<vector<unsigned char>> &m, vector<vector<unsigned char>> &a, Sensores sensores);
  

  /**
   * @brief Determina la casilla con menor frecuencia de las delanteras
   * 
   * @param fila fila del agente
   * @param col columna del agente
   * @param sensores sensores del agente
   * @return int casilla de la vision con menor frecuencia de pisada
   */
  int LessFreq(const Sensores &sensores);

  /**
   * @brief Obtiene la posicion sobre el sensor de vision de la casilla de frecuencia
   * 
   * @param fila pila de la casilla
   * @param col columna de la casilla
   * @param rumbo Orientacion del agente
   * 
   * @pre |fila|<=2 and |col|<=2
   * @return int Entero del 1 al 15
   */
  int GetPos(int fila,int col, Orientacion rumbo);

  /**
   * @brief Obtiene por referencia las posiciones sobre la matriz de frecuencias de los caminos posibles
   * 
   * @param f fila del agente
   * @param c columna del agente
   * @param sensores Sensores del agente
   * @param zap booleano que indica si el agente tiene zapatillas
   * @param camino vector con pares de posiciones en la matriz
   */
  void GetPaths(int f, int c, const Sensores & sensores, vector<pair<int,int>> &camino);

  /**
   * @brief Comprueba si la casilla es una de las que queremos y es viable por altura
   * 
   * @param sensores Sensores del agente
   * @param casilla casilla que queremos comprobar
   * 
   * @pre 0 < casilla < 16
   * @return true si la casilla es deseada 
   */
  bool CasillaDeseada(const Sensores & sensores, int casilla, const vector<unsigned char> & deseadas);

  /**
   * @brief Determina el comportamiento del agente
   * 
   * @param sensores Sensores del agente
   * @return int posicion a la que moverse
   */
  int Andar(const Sensores & sensores);


  /**
   * @brief Determina si hay existencias de un elemento en un vector
   * 
   * @param v vector 
   * @param x elemento a buscar
   * @return true si el elemento x esta en v.
   */
  bool IsIn(const vector<unsigned char> &v, char x){
      for (auto it=v.begin(); it!=v.end(); it++){
        if(*it==x) return true;
      }
      return false;
  }

  /**
   * @brief Imprime un vector de pares (DEBUG)
   * 
   * @param v vector a imprimir
   */
  void print(const vector<pair<int,int>> &v){
    for (auto it=v.begin(); it!=v.end(); it++){
      cout << '(' << (*it).first << ',' << (*it).second << ')';
    }
  }

  void ResetFrec(int f, int c, int k=3);

  void ActualizarFrecuencias(int f, int c, Orientacion rumbo);
//Datos miembro
private:
  Action last_action;              // Ultima accion realizada
  int giro45izq;                   // Contador para giros de 45 grados a la izquierda
  bool zap;           // Indica si el rescatador tiene zapatillas
  bool giro180_izq;                // Indica si el rescatador ha girado 180 grados a la izquierda
  vector<vector<int>> frecuencias; // Mapa de frecuencias de pisadas
  bool run;
};

#endif
