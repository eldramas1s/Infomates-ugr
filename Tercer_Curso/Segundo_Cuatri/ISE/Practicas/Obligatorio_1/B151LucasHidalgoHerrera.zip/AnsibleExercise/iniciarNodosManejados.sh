#!/bin/bash

ansible-playbook -i ./hosts.yaml ./FirstPart.yaml
