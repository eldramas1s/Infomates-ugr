#!/bin/bash

ansible-playbook -i ./hosts.yaml ./SecondPart.yaml
