package irrgarten;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 * 
 * @author airam
 */

 /**
  * @brief Direcciones posibles para realizar un movimiento.
  */
public enum Directions {
    
    LEFT, RIGHT, UP, DOWN
}
